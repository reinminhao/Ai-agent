def create_channel(name):
    # 创建频道
    return f"channel created: {name}"

def send_message(channel, message):
    # 发送消息
    return f"message sent to {channel}: {message}"
